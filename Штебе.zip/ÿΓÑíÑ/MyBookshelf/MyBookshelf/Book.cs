﻿
namespace MyBookshelf
{
     class Book
    {
		// Поле Id	
		public int idbooks { get; set; }
		// Название книги
		public string Title { get; set; }
		// Жанр книги
		public string Genre { get; set; }
		// Автор книги 
		public string Author { get; set; }
		// Год издания
		public int DateCreate { get; set; }
		// Описание книги
		public string Description { get; set; }
		
		
	}
}